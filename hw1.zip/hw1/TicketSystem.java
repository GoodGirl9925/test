import java.util.Random;

public class TicketSystem {
    // 定义常量
    private static final int INITIAL_TICKETS = 20;
    private static final int WINDOW_COUNT = 3;
    private static final int NEW_TICKET_INTERVAL = 5000;

    // 共享票池
    private static class TicketPool {
        private int tickets; // 余票数量

        public TicketPool(int tickets) {
            this.tickets = tickets;
        }

        // 售票
        public synchronized void sellTickets(int windowId, int num) {
            while (tickets < num) {
                System.out.println("窗口 " + windowId + " 余票不足，购票者等待...");
                try {
                    wait(); // 等待新票进入
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            tickets -= num;
            System.out.println("窗口 " + windowId + " 售出 " + num + " 张票，余票: " + tickets);
            notifyAll(); // 通知其他线程
        }

        // 退票
        public synchronized void returnTickets(int windowId, int num) {
            tickets += num;
            System.out.println("窗口 " + windowId + " 退票 " + num + " 张，余票: " + tickets);
            notifyAll(); // 通知等待的购票者
        }

        // 新进票
        public synchronized void addTickets(int num) {
            tickets += num;
            System.out.println("新进票 " + num + " 张，余票: " + tickets);
            notifyAll(); // 通知等待的购票者
        }
    }

    // 模拟售票窗口操作
    private static void simulateWindow(TicketPool ticketPool, int windowId) {
        Random random = new Random();
        while (true) {
            int operation = random.nextInt(2); // 随机选择售票或退票
            int num = random.nextInt(5) + 1; // 随机票数
            if (operation == 0) {
                ticketPool.sellTickets(windowId, num); // 售票
            } else {
                ticketPool.returnTickets(windowId, num); // 退票
            }
            try {
                Thread.sleep(random.nextInt(1000)); // 模拟操作间隔
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // 模拟新进票操作
    private static void simulateNewTickets(TicketPool ticketPool) {
        Random random = new Random();
        while (true) {
            try {
                Thread.sleep(NEW_TICKET_INTERVAL); // 每 5 秒新进票一次
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            int num = random.nextInt(10) + 1; // 随机新进票数
            ticketPool.addTickets(num);
        }
    }

    public static void main(String[] args) {
        TicketPool ticketPool = new TicketPool(INITIAL_TICKETS); // 初始票数 20
        System.out.println("初始所有窗口票数为: " + ticketPool.tickets);

        // 模拟三个售票窗口
        for (int i = 1; i <= WINDOW_COUNT; i++) {
            int windowId = i;
            new Thread(() -> simulateWindow(ticketPool, windowId)).start();
        }

        // 模拟新进票
        new Thread(() -> simulateNewTickets(ticketPool)).start();
    }
}