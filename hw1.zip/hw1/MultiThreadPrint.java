public class MultiThreadPrint {

    // 共享锁对象，用于线程间的同步
    private static final Object lock = new Object();
    // 控制打印顺序，true 表示轮到字母线程打印，false 表示轮到数字线程打印
    private static boolean isLetterTurn = true;

    public static void main(String[] args) {
        // 创建字母线程实例，使用继承 Thread 类的方式
        Thread letterThread = new LetterThread();
        // 创建数字线程实例，使用实现 Runnable 接口的方式
        Thread numberThread = new Thread(new NumberThread());

        // 启动字母线程
        letterThread.start();
        // 启动数字线程
        numberThread.start();
    }

    // 字母线程类，继承自 Thread 类
    static class LetterThread extends Thread {
        // 待打印的字母字符串
        private final String letters;

        // 构造函数，接收待打印的字母字符串
        public LetterThread() {
            this.letters = "abcde";
        }

        @Override
        public void run() {
            // 遍历字母字符串中的每个字符
            for (int i = 0; i < letters.length(); i++) {
                // 进入同步块，确保线程安全
                synchronized (lock) {
                    // 如果不是字母线程的打印时机，则线程进入等待状态
                    while (!isLetterTurn) {
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            // 打印异常堆栈信息
                            e.printStackTrace();
                        }
                    }
                    // 打印当前字母
                    System.out.print(letters.charAt(i));
                    // 切换打印顺序，轮到数字线程打印
                    isLetterTurn = false;
                    // 唤醒可能正在等待的数字线程
                    lock.notify();
                }
            }
        }
    }

    // 数字线程类，实现 Runnable 接口
    static class NumberThread implements Runnable {
        // 待打印的数字数组
        private final int[] numbers;

        // 构造函数，接收待打印的数字数组
        public NumberThread() {
            this.numbers = new int[]{1, 23, 456, 7891, 23456};
        }

        @Override
        public void run() {
            // 遍历数字数组中的每个数字
            for (int number : numbers) {
                // 进入同步块，确保线程安全
                synchronized (lock) {
                    // 如果不是数字线程的打印时机，则线程进入等待状态
                    while (isLetterTurn) {
                        try {
                            lock.wait();
                        } catch (InterruptedException e) {
                            // 打印异常堆栈信息
                            e.printStackTrace();
                        }
                    }
                    // 打印当前数字
                    System.out.print(number);
                    // 切换打印顺序，轮到字母线程打印
                    isLetterTurn = true;
                    // 唤醒可能正在等待的字母线程
                    lock.notify();
                }
            }
        }
    }
}